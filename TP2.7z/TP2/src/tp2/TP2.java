 
package tp2;

/**
 *
 * @author Thierry Despax
 * @version 2.0
 */
public class TP2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     /**
      * Appel fenetre principale d'Accueil
      */ 
     
        Accueil a= new Accueil();  
       /* Inscription i= new Inscription(); */ 
       /* Connexion c= new Connexion(); */
       /* Bienvenue b= new Bienvenue(); */ 
    }
    
}
